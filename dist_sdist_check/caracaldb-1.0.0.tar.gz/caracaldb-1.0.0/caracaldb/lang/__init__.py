"""Language frontends for CaracalDB."""
